echo "Pouet Pouet Pouet" >> boofar

mkdir dossier_tarte 2> /dev/null || true

echo "c'est bon les pommes" >> dossier_tarte/pommes

echo "fichier tres tres nul " >> nul

echo "VROOM" >> dossier_tarte/nul
